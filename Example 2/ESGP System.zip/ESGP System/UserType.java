/*
 * An enum to ensure to store the different user types.
 */
public enum UserType {
    Community,
    EncostVerified,
    EncostUnverified
}
