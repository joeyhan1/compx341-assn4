
/*
 * This class holds the userType attribute for a user
 */
public class User {

    // Declare variables
    private String userType;

    // Getters and setters
    public void setUserType(String userType) {
        this.userType = userType;
    }

    public String getUserType() {
        return this.userType;
    }
}