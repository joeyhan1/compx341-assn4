public class Main {
    public static void main(String[] args) {

        // Initialise console object
        ConsoleInOut console = new ConsoleInOut();

        // Read input in an infinite loop
        console.readInput();
    }
}