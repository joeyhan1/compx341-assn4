
/*
 * This class is primarily used to identify a user type of CommunityUser. The GraphVisuals() method is not utilised
 */
public class CommunityUser extends User {

    public void GraphVisuals() {

    }
}