import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.Assertions.*;
import java.io.*;
import java.util.List;
import org.graphstream.graph.*;
import org.graphstream.graph.implementations.*;

import java.util.Scanner;

/**
 * Class that performs black box unit tests on elements that make up high priority requirements for the Encost Smart Home Graph Project (ESGP)
 */
public class ESGPTest {
    private UserVerifier userVerifier;
    private FileParser fileParser;
    private ByteArrayOutputStream outputStreamCaptor = new ByteArrayOutputStream();

    // These paths will not work without the full path --> should change them
    String validPath = "C:/Users/jkonig/Downloads/Student_1/ESGP System/dataset.csv";
    String validPath2 = "C:/Users/jkonig/Downloads/Student_1/ESGP System/dataset2.csv";

    /**
     * Set up objects frequently used
     */
    @BeforeEach
    public void setUp() {
        userVerifier = new UserVerifier();
        fileParser = new FileParser();
    }

    //-------- Account Login Tests ------------
    //NOTE SOME PARAMETERS NEED TO BE UPDATED TO BE ABLE TO BE TESTED
    
    /**
     * Checks that when an invalid username and an invalid password are provided to the verifyUser
     * false is returned (credentials are recognised as invalid)
     */
    @Test
    public void accountLoginInvalidUsernameInvalidPassword() {
        setUp();
        String invalidUname = "user"; //-------------------------------- NEEDS TO BE POPULATED  
        String invalidPassword = "password"; //-------------------------------- NEEDS TO BE POPULATED  
        boolean validCredentials = userVerifier.verifyUser(invalidUname, invalidPassword);
        assertFalse(validCredentials);
    }

    /**
     * Checks that when an invalid username and a valid password are provided to the verifyUser
     * false is returned (credentials are recognised as invalid)
     */
    @Test
    public void accountLoginInvalidUsernameValidPassword() {
        setUp();
        String invalidUname = "user"; //-------------------------------- NEEDS TO BE POPULATED  
        String validPassword = "password789"; //-------------------------------- NEEDS TO BE POPULATED  
        boolean validCredentials = userVerifier.verifyUser(invalidUname, validPassword);
        assertFalse(validCredentials);
    }

    /**
     * Checks that when a valid username and an invalid password are provided to the verifyUser
     * false is returned (credentials are recognised as invalid)
     */
    @Test
    public void accountLoginValidUsernameInvalidPassword() {
        setUp();
        String validUname = "encostUserA"; //-------------------------------- NEEDS TO BE POPULATED  
        String invalidPassword = "password"; //-------------------------------- NEEDS TO BE POPULATED  
        boolean validCredentials = userVerifier.verifyUser(validUname, invalidPassword);
        assertFalse(validCredentials);
    }    

    /**
     * Checks that when a valid username and a valid password (it's corresponding password) are provided 
     * to the verifyUser true is returned (credentials are recognised as valid)
     */
    @Test
    public void accountLoginValidUsernameValidPassword() {
        setUp();
        String validUname = "encostUserA"; //-------------------------------- NEEDS TO BE POPULATED  
        String validPassword = "password789"; //-------------------------------- NEEDS TO BE POPULATED  
        boolean validCredentials = userVerifier.verifyUser(validUname, validPassword);
        assertTrue(validCredentials);
    }

    //-------- Loading Encost Dataset Tests ------------

    /**
     * Parses the Encost Dataset file and checks that the returned device array contains the same number
     * of Devices as lines in the Encost Dataset file (each line in the file represents one device)
     * Also checks that each device in the device array is not a null reference
     */
    @Test
    public void loadingEncostDatasetValidFilePath() {
        setUp();
        String encostDatasetFilePath = validPath; //-------------------------------- NEEDS TO BE POPULATED  
        int numDevicesEncostDatasetFile = 0; //-------------------------------- NEEDS TO BE POPULATED  
        Device [] deviceArray = fileParser.parseFile(encostDatasetFilePath);        
        assertNotNull(deviceArray);

        if(deviceArray != null){
            for(Device dev : deviceArray){
                assertNotNull(dev);
            }
        }
    }

    /**
     * Checks that a null Device array is returned when parseFile is passed an invalid filepath
     */
    @Test
    public void loadingEncostDatasetInvalidFilePath() {
        setUp();
        String invalidEncostDatasetFilePath = "data.csv"; //-------------------------------- NEEDS TO BE POPULATED  
        Device [] deviceArray = fileParser.parseFile(invalidEncostDatasetFilePath);
        assertNull(deviceArray);
    }

    /**
     * Checks that a null Device array is returned when parseFile is passed an empty string as the filepath
     */
    @Test
    public void loadingEncostDatasetEmptyStringFilePath() {
        setUp();
        String emptyString = "";
        Device [] deviceArray = fileParser.parseFile(emptyString);
        assertNull(deviceArray);
    }

    /**
     * Checks that a null Device array is returned when parseFile is passed a null string as the filepath
     */
    @Test
    public void loadingEncostDatasetNullStringFilePath() {
        setUp();
        String nullString = null;
        Device [] deviceArray = fileParser.parseFile(nullString);
        assertNull(deviceArray);
    }

    //-------- Categorising Devices ------------

    /**
     * Checks that the Device array returned when parseFile is passed the Encost Dataset contains the same number
     * of Devices as lines in the Encost Dataset file (each line in the file represents one device)
     * And that devoce array has the same number of routers, whiteware, hubs, appliances and lighting as there are in the 
     * Encost Dataset
     */
    @Test
    public void categoriseDevicesEncostDataset() {
        fileParser = new FileParser();
        String encostDatasetFilePath = validPath; //-------------------------------- NEEDS TO BE POPULATED  
        int numDevicesEncostDatasetFile = 12; //-------------------------------- NEEDS TO BE POPULATED
        int numRouterEncostDatasetFile = 5; //-------------------------------- NEEDS TO BE POPULATED
        int numWhitewareEncostDatasetFile = 2; //-------------------------------- NEEDS TO BE POPULATED
        int numHubEncostDatasetFile = 1; //-------------------------------- NEEDS TO BE POPULATED
        int numApplianceEncostDatasetFile = 2; //-------------------------------- NEEDS TO BE POPULATED
        int numLightingEncostDatasetFile = 2; //-------------------------------- NEEDS TO BE POPULATED
        Device[] deviceArray = fileParser.parseFile(encostDatasetFilePath);

        int countRouter = 0; 
        int countWhiteware = 0; 
        int countHub = 0;
        int countAppliance = 0;
        int countLighting = 0;

        for(Device dev : deviceArray){
            if (dev.getDeviceCategory() == Device.DeviceCategory.WIFI_ROUTER){
                countRouter++;
            } else if (dev.getDeviceCategory() == Device.DeviceCategory.WHITEWARE){
                countWhiteware++;
            } else if(dev.getDeviceCategory() == Device.DeviceCategory.HUB_CONTROLLER){
                countHub++;
            } else if(dev.getDeviceCategory() == Device.DeviceCategory.APPLIANCE){
                countAppliance++;
            } else if(dev.getDeviceCategory() == Device.DeviceCategory.LIGHTING){
                countLighting++;
            }
        }

        assertEquals(numDevicesEncostDatasetFile, deviceArray.length);
        assertEquals(numRouterEncostDatasetFile, countRouter);
        assertEquals(numApplianceEncostDatasetFile, countAppliance);
        assertEquals(numLightingEncostDatasetFile, countLighting);
        assertEquals(numHubEncostDatasetFile, countHub);
        assertEquals(numWhitewareEncostDatasetFile, countWhiteware);
    }

    @Test
    public void categoriseDevicesInvalidFileFormat() {
        FileParser fileParser = new FileParser();
        String incorrectFormatFilePath = ""; //-------------------------------- NEEDS TO BE POPULATED  
        Device [] deviceArray = fileParser.parseFile(incorrectFormatFilePath);
        assertNull(deviceArray);
    }

    //--------Building graph data type ------------

    /**
     * Checks to see that when a DeviceGraph is created for a file that has been parsed and is not valid
     * that the number of devices in the DeviceGraph is zero
     */
    @Test
    public void buildGraphEmptyStringFilePath() {
        FileParser fileParser = new FileParser();
        String emptyString = "";
        Device[] deviceArray = fileParser.parseFile(emptyString);
        DeviceGraph deviceGraph = new DeviceGraph(deviceArray);
        assertEquals(0, deviceGraph.getDevices().length);
    }


    /**
     * Checks to see that when a DeviceGraph is created for a file that has been parsed and is not valid
     * that the number of devices in the DeviceGraph is zero
     */
    @Test
    public void buildGraphInvalidFilePath() {
        FileParser fileParser = new FileParser();
        String invalidEncostDatasetFilePath = "data.csv"; //-------------------------------- NEEDS TO BE POPULATED  
        Device [] deviceArray = fileParser.parseFile(invalidEncostDatasetFilePath);
        DeviceGraph deviceGraph = new DeviceGraph(deviceArray);
        assertEquals(0, deviceGraph.getDevices().length);
    }

    // /**
    //  * Checks to see that when passed a valid file the correct number of devices exist in the DeviceGraph
    //  * validFilePathVOne in this example contains the following devices:
    //  * WifiRouter (id: EWR-1234), SmartAppliance (router id: EWR-1234), SmartWhiteware (router id: EWR-1234), 
    //  * HubController (router id: EWR-1234), WifiRouter (id: EWR-6789), SmartAppliance (router id: EWR-6789)
    //  * i.e. six devices
    //  */
    @Test
    public void buildGraphValidFileA() {
        FileParser fileParser = new FileParser();
        String validFilePathVOne = validPath; //-------------------------------- NEEDS TO BE POPULATED  
        Device [] deviceArray = fileParser.parseFile(validFilePathVOne);
        DeviceGraph deviceGraph = new DeviceGraph(deviceArray);

        assertEquals(12, deviceGraph.getDevices().length);
    }    

    // /**
    //  * Checks to see that when passed a valid file the correct number of devices exist in the DeviceGraph
    //  * validFilePathVTwo in this example contains the following devices:
    //  * WifiRouter (id: EWR-1234), WifiRouter (id: EWR-6789) i.e. two devices
    //  */
    @Test
    public void buildGraphValidFileB() {
        FileParser fileParser = new FileParser();
        String validFilePathVTwo = validPath2; //-------------------------------- NEEDS TO BE POPULATED  
        Device [] deviceArray = fileParser.parseFile(validFilePathVTwo);
        DeviceGraph deviceGraph = new DeviceGraph(deviceArray);

        assertEquals(2, deviceGraph.getDevices().length);
    } 
}
