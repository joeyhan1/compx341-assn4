/*
 * Main method to run the ESGP
 */
public class ESGP {
    
    public static void main(String[] args)
    {
        ConsoleApp app = new ConsoleApp();
    }
}
