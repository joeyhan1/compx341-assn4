import java.io.BufferedReader;
import java.io.FileReader;
import java.math.BigInteger;
import java.security.MessageDigest;

public class UserVerifier {

    // Stores the path of the file containing usernames and their encrypted passwords
    String USER_DETAILS_FILEPATH = "users.txt";

    /*
     * Initialises a new object
     */
    public UserVerifier(){

    }

    private String hashPassword(String password){

        try{
            // create a message digest for MD5 hash
            MessageDigest md = MessageDigest.getInstance("MD5");
            // turn password into a byte array and hash
            byte[] messageDigest = md.digest(password.getBytes());
            // turn byte array into integer
            BigInteger no = new BigInteger(1, messageDigest);
            // turn integer into hex string
            String hashText = no.toString(16);
            
            return hashText;
        }
        catch(Exception ex){
            return null;
        }
    }

    /*
     * Returns a boolean of whether the username/passwrod pair are valid
     * @param username
     * @param password
     * @return boolean, true if they are a valid pair, false if invalid
     */
    public Boolean verifyUser(String username, String password){

        // hash the password
        password = hashPassword(password);

        try{
            BufferedReader reader = new BufferedReader(new FileReader(USER_DETAILS_FILEPATH));
            String line;
            String[] pair;

            // loops through all the lines
            while((line = reader.readLine()) != null){
                pair = line.split(",");

                // if the username is valid
                if(pair[0].compareTo(username) == 0){

                    // if the password matches the username
                    if(pair[1].compareTo(password) == 0){
                        return true;
                    }
                    return false;
                }
            }
        }
        catch(Exception ex){
            System.out.println("Error reading usernames.");
        }

        // correct username/password pair has not been found
        return false;
    }
    
}
