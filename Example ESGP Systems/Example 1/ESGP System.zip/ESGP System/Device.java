import java.util.Date;
import java.util.Dictionary;
import java.util.Hashtable;

/*
 * Class which holds information about a device
 */
public class Device {

    // Public enum for the category of the device
    public enum DeviceCategory{
        WIFI_ROUTER,
        HUB_CONTROLLER,
        WHITEWARE,
        LIGHTING,
        APPLIANCE,
        NONE
    }

    // Public dictionary showing the relationship between device type and category
    public Dictionary<String, DeviceCategory> dictDeviceCategory = new Hashtable<>();
    
    // Private variables holding information about the device
    private String deviceID;
    private Date dateConnected;
    private String deviceName;
    private String deviceType;
    private DeviceCategory deviceCategory;
    private String householdID;
    private String routerConnection;
    private Boolean sends;
    private Boolean receives;

    /*
     * Initialises new device object with the passed in values
     */
    public Device(String deviceID, 
    Date dateConnected, 
    String deviceName, 
    String deviceType,
    String householdID,
    String routerConnection,
    Boolean sends,
    Boolean receives){

        // fill the dictionary
        FillDictionary();

        // set the private variables
        this.deviceID = deviceID;
        this.dateConnected = dateConnected;
        this.deviceName = deviceName;
        this.deviceType = deviceType;
        this.householdID = householdID;
        this.routerConnection = routerConnection;
        this.sends = sends;
        this.receives = receives;

        // calculate the device category from the type
        this.deviceCategory = findCategory(this.deviceType);
    }

    /*
     * Fills the dictionary with relationship between device type and category Enum
     */
    private void FillDictionary(){
        // fills WIFI_ROUTER
        dictDeviceCategory.put("Router".toLowerCase(), DeviceCategory.WIFI_ROUTER);
        dictDeviceCategory.put("Extender".toLowerCase(), DeviceCategory.WIFI_ROUTER);
        
        // fills HUB_CONTROLLER
        dictDeviceCategory.put("Hub/Controller".toLowerCase(), DeviceCategory.HUB_CONTROLLER);

        // fills LIGHTING
        dictDeviceCategory.put("Light Bulb".toLowerCase(), DeviceCategory.LIGHTING);
        dictDeviceCategory.put("Strip Lighting".toLowerCase(), DeviceCategory.LIGHTING);
        dictDeviceCategory.put("Other Lighting".toLowerCase(), DeviceCategory.LIGHTING);

        // fills APPLIANCE
        dictDeviceCategory.put("Kettle".toLowerCase(), DeviceCategory.APPLIANCE);
        dictDeviceCategory.put("Toaster".toLowerCase(), DeviceCategory.APPLIANCE);
        dictDeviceCategory.put("Coffee Maker".toLowerCase(), DeviceCategory.APPLIANCE);

        // fills WHITEWARE
        dictDeviceCategory.put("Washing Machine/Dryer".toLowerCase(), DeviceCategory.WHITEWARE);
        dictDeviceCategory.put("Refrigerator/Freezer".toLowerCase(), DeviceCategory.WHITEWARE);
        dictDeviceCategory.put("Dishwasher".toLowerCase(), DeviceCategory.WHITEWARE);
    }

    /*
     * Returns the device category from its type
     * @param type, the device type
     * @return device category
     */
    private DeviceCategory findCategory(String type){
        DeviceCategory category = dictDeviceCategory.get(type.toLowerCase());
        if(category == null){
            return DeviceCategory.NONE;
        }
        return category;
    }

    /*
     * Returns the device ID
     * @return device ID
     */
    public String getDeviceID(){
        return deviceID;
    }

    /*
     * Returns the connected date
     * @return connected date
     */
    public Date getDateConnected(){
        return dateConnected;
    }

    /*
     * Returns the product name of the device
     * @return device product name
     */
    public String getDeviceName(){
        return deviceName;
    }

    /*
     * Returns the type of the device
     * @return device type
     */
    public String getDeviceType(){
        return deviceType;
    }

    /*
     * Returns the category of the device
     * @return device category
     */
    public DeviceCategory getDeviceCategory(){
        return deviceCategory;
    }

    /*
     * Returns the household ID
     * @return household ID
     */
    public String getHouseholdID(){
        return householdID;
    }

    /*
     * Returns the connected router
     * @return router
     */
    public String getRouterConnection(){
        return routerConnection;
    }

    /*
     * Returns whether the device has the ability to send
     * @return true if the device can send, false if not
     */
    public Boolean isSender(){
        return sends;
    }

    /*
     * Returns whether the device has the ability to receive
     * @return true if the device can receive, false if not
     */
    public Boolean isReceiver(){
        return receives;
    }
}
