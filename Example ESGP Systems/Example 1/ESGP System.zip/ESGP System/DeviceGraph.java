import java.util.ArrayList;
import java.util.List;

/*
 * Class which creates an adjacency matrix to show the connections between devices.
 */
public class DeviceGraph {

    // array of devices
    Device[] devices;

    // the graph data structure as an adjacency matrix
    int[][] adjacencyMatrix;

    public DeviceGraph(Device[] devices){

        // if there are no devices
        if(devices == null){
            return;
        }
        
        // convert the list into an array
        this.devices = devices;
        // setup the adjacency matrix
        adjacencyMatrix = new int[devices.length][devices.length];
        fillMatrix();
        createEdges();
    }

    /*
     * Fills the adjacencyMatrix with 0s
     */
    private void fillMatrix(){
        // for each row
        for(int row = 0; row < adjacencyMatrix.length; row++){
            // for each column
            for(int col = 0; col < adjacencyMatrix[row].length; col++){
                adjacencyMatrix[row][col] = 0;
            }
        }
    }

    /*
     * Returns array of device objects
     * @return array of devices
     */
    public Device[] getDevices(){
        if(devices == null){
            return new Device[0];
        }
        return devices;
    }

    /*
     * Returns an array of devices a device is connected to
     * @param deviceID, the id of the device to find neighbours
     * @return, an array of neighbouring device objects
     */
    public Device[] getNeighbours(String deviceID){

        int deviceIndex = -1;
        List<Device> connectedDevices = new ArrayList<>();
        
        // find the index of the device
        for(int i = 0; i < devices.length; i++){
            // if it is the device
            if(devices[i].getDeviceID().compareTo(deviceID) == 0){
                deviceIndex = i;
            }
        }

        // if an invalid deviceID was entered
        if(deviceIndex == -1){
            return null;
        }

        // loop through device row of passed in device
        for(int col = 0; col < adjacencyMatrix[deviceIndex].length; col++){
            // if the devices are connected
            if(adjacencyMatrix[deviceIndex][col] == 1){
                // device is at position col
                connectedDevices.add(devices[col]);
            }
        }

        // convert the list to an array and return
        return connectedDevices.toArray(new Device[0]);
    }

    /*
     * Populates the adjacency list with connections
     */
    private void createEdges(){

        // loops through all the devices
        for(int i = 0; i < devices.length; i++){

            Device device = devices[i];

            // if the device is a router, don't need to insert anything
            if(device.getRouterConnection().compareTo("-") != 0){

                String deviceRouter = device.getRouterConnection();

                // loop through devices trying to find router
                for(int j = 0; j < devices.length; j++){
                    // if the device is the router
                    if(devices[j].getDeviceID().compareTo(deviceRouter) == 0){

                        // if device can receive
                        if(device.isReceiver()){
                            // adds the connection of the router to device
                            adjacencyMatrix[j][i] = 1;
                        }

                        // if device can send
                        if(device.isSender()){
                            // adds the connection of the device to router
                            adjacencyMatrix[i][j] = 1;
                        }
                    }
                }
            }
        }
    }

    /*
     * Method to print the adjacency matrix - for testing purposes
     */
    public void printMatrix(){
        for(int row = 0; row < adjacencyMatrix.length; row++){
            System.out.print(devices[row].getDeviceID() + " ");
            for(int col = 0; col < adjacencyMatrix[row].length; col++){
                System.out.print(adjacencyMatrix[row][col] + " ");
            }
            System.out.println();
        }
    }
}
