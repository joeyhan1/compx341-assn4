import org.graphstream.graph.*;
import org.graphstream.graph.implementations.*;

import java.util.Scanner;

/*
 * Class which creates a GraphStream graph object to visualise device information
 */
public class GraphVisualiser {
    
    // Holds the GraphSteam graph of the data
    private Graph graph;

    // Initialises a new object
    public GraphVisualiser(){}

    /*
     * Creates the Graph object from the DeviceGraph
     * @param deviceGraph, the DeviceGraph object holding the device information
     */
    public void convertGraph(DeviceGraph deviceGraph){

        // if the DeviceGraph is null, do not create Graph
        if(deviceGraph == null){
            return;
        }

        graph = new SingleGraph("Data Visualisation");

        // add the css stylesheet
        String cssFilePath = new Scanner(GraphVisualiser.class.getResourceAsStream("stylesheet.css"), "UTF-8").useDelimiter("\\A").next();
		graph.addAttribute("ui.stylesheet", cssFilePath);

        addNodes(deviceGraph);
        addEdges(deviceGraph);
    }

    /*
     * Adds the devices (nodes) to the graph
     * @param deviceGraph, the DeviceGraph object holding the device information
     */
    private void addNodes(DeviceGraph deviceGraph){

        // loops through all the devices to add as nodes
        for(int i = 0; i < deviceGraph.getDevices().length; i++){

            Device d = deviceGraph.getDevices()[i];
            Node node = graph.addNode(d.getDeviceID());
            node.setAttribute("ui.class", d.getDeviceCategory().toString());
            node.setAttribute("ui.label", d.getDeviceName());
        }
    }

    /*
     * Adds the connections (edges) between the devices to the graph
     * @param deviceGraph, the DeviceGraph object holding the device information
     */
    private void addEdges(DeviceGraph deviceGraph){

        // loops through all the devices to find its neighbours
        for(int i = 0; i < deviceGraph.getDevices().length; i++){

            Device d = deviceGraph.getDevices()[i];
            Device[] neighbours = deviceGraph.getNeighbours(d.getDeviceID());

            // loop through all the device neighbours
            for(int j = 0; j < neighbours.length; j++){
                graph.addEdge(d.getDeviceID() + ":" + neighbours[j].getDeviceID(), d.getDeviceID(), neighbours[j].getDeviceID(), true);
            }
        }

    }

    /*
     * If the graph exists, display in UI window
     */
    public void visualiseGraph(){

        // if no graph object, return
        if(graph == null){
            return;
        }

        System.setProperty("org.graphstream.ui.renderer", "org.graphstream.ui.j2dviewer.J2DGraphRenderer"); // GS 1.3
        graph.display();
    }

    /*
     * Returns the number of nodes in the graph
     * @return, the number of nodes in the graph
     */
    public int getNumNodes(){

        int count = 0;

        // loops through all nodes in the graph
        for(Node n:graph) {
            count++;
        }

        return count;
    }

    /*
     * Returns the number of edges in the graph
     * @return, the number of edges in the graph
     */
    public int getNumEdges(){

        int count = 0;

        // loops through all edges in the graph
        for(Edge e:graph.getEachEdge()) {
            count++;
        }

        return count;

    }
}
