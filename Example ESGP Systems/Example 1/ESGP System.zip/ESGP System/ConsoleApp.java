import java.io.File;
import java.util.List;

public class ConsoleApp {

    // String holding the location of the default dataset
    private String ENCOST_DATASET_FILEPATH = "Encost Smart Homes Dataset (bigger).csv";

    // Boolean value holding the type of user - community(F) or encost(T)
    private Boolean userIsVerified = false;

    // String holding the location of a custom dataset
    private String customFilePath = null;

    // DeviceGraph object which holds the data in a graph data type
    private DeviceGraph deviceGraph;

    /*
     * Initialises a new object and calls the main method
     */
    public ConsoleApp(){
        main();
    }


    public void main(){

        getUserVersion();
    }

    /*
     * Asks user to select their type - community or encost.
     * Loops until valid input is supplied.
     */
    private void getUserVersion(){

        Boolean successful = false;

        // loops until valid user input
        while(!successful){
            // prints the prompt
            System.out.println("Welcome to the Encost Smart Graph Project!");
            System.out.println("Select user:");
            System.out.println("    (1) Community");
            System.out.println("    (2) Encost");
            System.out.print(">> ");
            // read in user input
            String input = System.console().readLine().trim();
            // checks input validity
            successful = checkUserVersion(input);
        }

        // if encost user, proceed to login
        if(userIsVerified){
            Boolean verifySuccess = verifyUser();
            
            // if the combination is invalid
            if(!verifySuccess){
                System.out.println("Unsuccessful login attempt");
                System.out.println();
                getUserVersion();
            }
        }

        // display features
        System.out.println();
        selectFeature();
    }

    /*
     * Returns whether the user input is valid, and sets whether the user is verified.
     * @param input, the user input to validate
     * @return Boolean, false if the input is invalid or true if it is valid
     */
    private Boolean checkUserVersion(String input){

        // community user
        if(input.compareTo("1") == 0){
            userIsVerified = false;
            return true;
        }
        // encost user
        else if(input.compareTo("2") == 0){
            userIsVerified = true;
            return true;
        }
        // invalid input
        else{
            System.out.println("Invalid user type - enter 1 or 2.");
            return false;
        }
    }

    /*
     * Returns whether the login attempt was successful
     * @return boolean, true if successful login and false if unsuccessful
     */
    private Boolean verifyUser(){

        // gets the username and the password from the user
        System.out.print("Enter username: ");
        String username = System.console().readLine();
        System.out.print("Enter password: ");
        String password = System.console().readLine();

        UserVerifier userVerifier = new UserVerifier();
        Boolean valid = userVerifier.verifyUser(username, password);

        return valid;
    }

    /*
     * Displays the feature options and calls the method for the selected feature.
     * Loads the file before looping the options.
     */
    private void selectFeature(){

        // loads file
        loadFile();

        // repeat forever
        while(true){

            // encost user
            if(userIsVerified){
                // displays features
                System.out.println("Encost Features");
                System.out.println("    (1) Load custom dataset");
                System.out.println("    (2) Data visualisation");
                System.out.println("    (3) View summary statistics");
                System.out.print(">> ");
                String option = System.console().readLine();

                // if selected the first item
                if(option.compareTo("1") == 0){
                    // call method
                    System.out.println("Load dataset");
                }
                // if selected the second item
                else if(option.compareTo("2") == 0){
                    // call method to display graph
                    displayGraph();
                }
                // if selected the third item
                else if(option.compareTo("3") == 0){
                    // call method
                    System.out.println("Summary Statistics");
                }
                // if option is invalid
                else{
                    System.out.println("Please select a valid option");
                }

                System.out.println();

            }
            // community user
            else{
                // displays features and gets user input
                System.out.println("Community Features:");
                System.out.println("    (1) Data visualisation");
                System.out.print(">> ");
                String option = System.console().readLine();

                // if user has inputted anything except 1
                if(option.compareTo("1") != 0){
                    System.out.println("Please select a valid option");
                    System.out.println();
                    continue;
                }

                // call method to display graph
                displayGraph();
                System.out.println();
            }
        }
    }

    /*
     * Loads a file to create the graph data type of Device objects.
     * Determines whether to use the default or custom file path. 
     */
    private void loadFile(){

        String filePath = ENCOST_DATASET_FILEPATH;

        // if a custom datapath has been entered
        if(userIsVerified && customFilePath != null){
            filePath = customFilePath;
        }
        
        // read the file and return list of device objects
        FileParser fileParser = new FileParser();
        Device[] devices = fileParser.parseFile(filePath);        

        // create DeviceGraph
        if(devices != null){
            System.out.println("Data loaded successfully.");
            System.out.println();
            deviceGraph = new DeviceGraph(devices);
        }
    }

    /*
     * Creates a new GraphVisualiser object to visuale the data using the GraphStream Library
     */
    private void displayGraph(){

        GraphVisualiser graph = new GraphVisualiser();
        graph.convertGraph(deviceGraph);
        graph.visualiseGraph();
    }

    /*
     * 
     */
    private void showSummary(){

        /*
         * create a DataSummary object which can be used to
        calculate device distribution, location, and connectivity. The strings returned by these
        functions will then be printed to the user in the console.
         */
    }

    /*
     * 
     */
    private void getCustomFile(){

        /*
         *  prompt the user to enter a file path. If it is a valid file
        path, loadFile will be called to replace deviceGraph with the information from the new
        data set.
         */
    }    
}
