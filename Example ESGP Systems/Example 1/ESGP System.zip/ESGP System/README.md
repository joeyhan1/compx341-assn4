To compile:
>> javac -cp "gs-core-1.3.jar;gs-ui-1.3.jar" Device.java DeviceGraph.java GraphVisualiser.java ConsoleApp.java FileParser.java UserVerifier.java ESGP.java

To run:
>> java -cp ".;gs-core-1.3.jar;gs-ui-1.3.jar" ESGP

To test:
>> javac -cp "gs-core-1.3.jar;gs-ui-1.3.jar;junit-platform-console-standalone-1.8.2.jar" *.java
>> java -jar junit-platform-console-standalone-1.8.2.jar -cp ".;gs-core-1.3.jar;gs-ui-1.3.jar" -c ESGPTest