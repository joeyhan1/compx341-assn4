import java.io.BufferedReader;
import java.io.FileReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/*
 * Class which opens and reads a file, creating Device objects
 */
public class FileParser {

    public FileParser(){}

    /*
     * Reads a file, creating a Device object for each line
     * @param filePath, the filepath of the file to opne
     * @return array of Device objects
     */
    public Device[] parseFile(String filePath){

        List<Device> devices = new ArrayList<>();

        try{

            BufferedReader reader = new BufferedReader(new FileReader(filePath));
            String line;
            String[] deviceSplit;

            // loops through all the lines
            while((line = reader.readLine()) != null){

                // split the line into an array
                deviceSplit = line.split(",");

                // incorrect number of information - exit program
                if(deviceSplit.length != 8){

                    System.out.println("Error reading file.");
                    return null;
                }

                // extract information from the array
                String deviceID = deviceSplit[0];
                Date connectedDate = new SimpleDateFormat("dd/MM/yy").parse(deviceSplit[1]);
                String deviceName = deviceSplit[2];
                String deviceType = deviceSplit[3];
                String householdID = deviceSplit[4];
                String routerConnection = deviceSplit[5];
                Boolean sends = false;
                Boolean receives = false;

                // determines the boolean values
                if(deviceSplit[6].compareTo("Yes") == 0){
                    sends = true;
                }
                if(deviceSplit[7].compareTo("Yes") == 0){
                    receives = true;
                }

                Device device = new Device(deviceID, connectedDate, deviceName, deviceType, householdID, routerConnection, sends, receives);
                devices.add(device);
            }

            reader.close();
            return devices.toArray(new Device[0]);
        }
        catch(Exception ex){
            System.out.println("Error reading file.");
        }

        return null;
    }
}
